/* eslint-disable */
import * as THREE from 'three'
import * as React from 'react'
import { useRef, useState } from 'react'
import { Canvas, useFrame, useLoader } from '@react-three/fiber'
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader'
import { FBXLoader } from 'three/examples/jsm/loaders/FBXLoader'

function Box(props: JSX.IntrinsicElements['mesh']) {
  // This reference will give us direct access to the THREE.Mesh object
  const ref = useRef<THREE.Mesh>(null!)
  // Rotate mesh every frame, this is outside of React without overhead
  const fbx = useLoader(GLTFLoader, '/Cup3.glb')
  return <primitive object={fbx.scene} />
}

export default function App() {
  return (
    <Canvas camera={{ fov: 35, zoom: 1.3, near: 1, far: 1000 }}>
      <ambientLight intensity={0.5} />
      <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} />
      <pointLight position={[-10, -10, -10]} />
      <Box position={[0, 0, 0]} scale={[1000, 1000, 1000]} />
    </Canvas>
  )
}
